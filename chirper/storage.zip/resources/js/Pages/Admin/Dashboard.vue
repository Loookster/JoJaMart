<script setup>
import { onMounted } from "vue";
import { initFlowbite } from "flowbite";
import AdminLayout from "./Components/AdminLayout.vue";
// initialize components based on data attribute selectors

</script>

<template>
    <!-- TODO: ADD TOTAL USERS, PRODUCTS, CATEGORIES, BRANDS-->
    <AdminLayout>
        <div>

        </div>
        <div>

        </div>
        <div>

        </div>

    </AdminLayout>
</template>
